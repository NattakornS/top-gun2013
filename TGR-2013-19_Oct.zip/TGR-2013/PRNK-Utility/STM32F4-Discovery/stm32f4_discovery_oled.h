/**
  ******************************************************************************
  * @file    stm324xg_discovery_OLED.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   This file contains all the functions prototypes for the 
  *          stm324xg_discovery_OLED.c driver.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; Portions COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************  
  */ 
/**
  ******************************************************************************
  * <h2><center>&copy; Portions COPYRIGHT 2012 Embest Tech. Co., Ltd.</center></h2>
  * @file    stm32f4_discovery_OLED.h
  * @author  CMP Team
  * @version V1.0.0
  * @date    28-December-2012
  * @brief   This file contains all the functions prototypes for the 
  *          stm324xg_discovery_OLED.c driver.
  *          Modified to support the STM32F4DISCOVERY, STM32F4DIS-BB, STM32F4DIS-CAM
  *          and STM32F4DIS-OLED modules.      
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Embest SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
  * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
  * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F4_DISCOVERY_OLED_H
#define __STM32F4_DISCOVERY_OLED_H

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "fonts.h"

/** @addtogroup Utilities
  * @{
  */

/** @addtogroup STM32F4_DISCOVERY
  * @{
  */ 

/** @addtogroup STM32F4_DISCOVERY
  * @{
  */
    
/** @addtogroup STM32F4_DISCOVERY_OLED
  * @{
  */ 


/** @defgroup STM32F4_DISCOVERY_OLED_Exported_Types
  * @{
  */
typedef struct 
{
  int16_t X;
  int16_t Y;
} Point, * pPoint;   
/**
  * @}
  */ 


/** 
  * @brief Various internal SD2119 registers name labels
  */
#define SSD2119_DEVICE_CODE_READ_REG  0x00
#define SSD2119_OSC_START_REG         0x00
#define SSD2119_OUTPUT_CTRL_REG       0x01
#define SSD2119_OLED_DRIVE_AC_CTRL_REG 0x02
#define SSD2119_PWR_CTRL_1_REG        0x03
#define SSD2119_DISPLAY_CTRL_REG      0x07
#define SSD2119_FRAME_CYCLE_CTRL_REG  0x0B
#define SSD2119_PWR_CTRL_2_REG        0x0C
#define SSD2119_PWR_CTRL_3_REG        0x0D
#define SSD2119_PWR_CTRL_4_REG        0x0E
#define SSD2119_GATE_SCAN_START_REG   0x0F
#define SSD2119_SLEEP_MODE_1_REG      0x10
#define SSD2119_ENTRY_MODE_REG        0x11
#define SSD2119_SLEEP_MODE_2_REG      0x12
#define SSD2119_GEN_IF_CTRL_REG       0x15
#define SSD2119_PWR_CTRL_5_REG        0x1E
#define SSD2119_RAM_DATA_REG          0x22
#define SSD2119_FRAME_FREQ_REG        0x25
#define SSD2119_ANALOG_SET_REG        0x26
#define SSD2119_VCOM_OTP_1_REG        0x28
#define SSD2119_VCOM_OTP_2_REG        0x29
#define SSD2119_GAMMA_CTRL_1_REG      0x30
#define SSD2119_GAMMA_CTRL_2_REG      0x31
#define SSD2119_GAMMA_CTRL_3_REG      0x32
#define SSD2119_GAMMA_CTRL_4_REG      0x33
#define SSD2119_GAMMA_CTRL_5_REG      0x34
#define SSD2119_GAMMA_CTRL_6_REG      0x35
#define SSD2119_GAMMA_CTRL_7_REG      0x36
#define SSD2119_GAMMA_CTRL_8_REG      0x37
#define SSD2119_GAMMA_CTRL_9_REG      0x3A
#define SSD2119_GAMMA_CTRL_10_REG     0x3B
#define SSD2119_V_RAM_POS_REG         0x44
#define SSD2119_H_RAM_START_REG       0x45
#define SSD2119_H_RAM_END_REG         0x46
#define SSD2119_X_RAM_ADDR_REG        0x4E
#define SSD2119_Y_RAM_ADDR_REG        0x4F

#define ENTRY_MODE_DEFAULT 0x6830
#define ENTRY_MODE_BMP 	   0x6810
#define MAKE_ENTRY_MODE(x) ((ENTRY_MODE_DEFAULT & 0xFF00) | (x))

/** 
  * @brief The dimensions of the OLED panel.
  */
#define OLED_VERTICAL_MAX   240
#define OLED_HORIZONTAL_MAX 320

/** 
  * @brief Various definitions controlling coordinate space mapping and drawing
           direction in the four supported orientations.   
  */
#define PORTRAIT

#ifdef PORTRAIT
#define HORIZ_DIRECTION 0x28
#define VERT_DIRECTION 0x20
#define MAPPED_X(x, y) (319 - (y))
#define MAPPED_Y(x, y) (x)
#endif
#ifdef LANDSCAPE
#define HORIZ_DIRECTION 0x00
#define VERT_DIRECTION  0x08
#define MAPPED_X(x, y) (319 - (x))
#define MAPPED_Y(x, y) (239 - (y))
#endif
#ifdef PORTRAIT_FLIP
#define HORIZ_DIRECTION 0x18
#define VERT_DIRECTION 0x10
#define MAPPED_X(x, y) (y)
#define MAPPED_Y(x, y) (239 - (x))
#endif
#ifdef LANDSCAPE_FLIP
#define HORIZ_DIRECTION 0x30
#define VERT_DIRECTION  0x38
#define MAPPED_X(x, y) (x)
#define MAPPED_Y(x, y) (y)
#endif

/** @defgroup STM32F4_DISCOVERY_OLED_Exported_Constants
  * @{
  */ 

/**
 * @brief Uncomment the line below if you want to use user defined Delay function
 *        (for precise timing), otherwise default _delay_ function defined within
 *         this driver is used (less precise timing).  
 */
/* #define USE_Delay */

#ifdef USE_Delay
#include "main.h" 
  #define _delay_     Delay  /* !< User can provide more timing precise _delay_ function
                                   (with 10ms time base), using SysTick for example */
#else
  #define _delay_     delay      /* !< Default _delay_ function with less precise timing */
#endif

/** 
  * @brief  OLED color  
  */ 
#define OLED_COLOR_WHITE          0xFFFF
#define OLED_COLOR_BLACK          0x0000
#define OLED_COLOR_GREY           0xF7DE
#define OLED_COLOR_BLUE           0x001F
#define OLED_COLOR_BLUE2          0x051F
#define OLED_COLOR_RED            0xF800
#define OLED_COLOR_MAGENTA        0xF81F
#define OLED_COLOR_GREEN          0x07E0
#define OLED_COLOR_CYAN           0x7FFF
#define OLED_COLOR_YELLOW         0xFFE0

#define White		         OLED_COLOR_WHITE
#define Black		         OLED_COLOR_BLACK
#define Red		         OLED_COLOR_RED
#define Blue		         OLED_COLOR_BLUE
#define Green		         OLED_COLOR_GREEN
#define Cyan                     OLED_COLOR_CYAN

/** 
  * @brief  OLED Lines depending on the chosen fonts.  
  */
#define OLED_LINE_0               LINE(0)
#define OLED_LINE_1               LINE(1)
#define OLED_LINE_2               LINE(2)
#define OLED_LINE_3               LINE(3)
#define OLED_LINE_4               LINE(4)
#define OLED_LINE_5               LINE(5)
#define OLED_LINE_6               LINE(6)
#define OLED_LINE_7               LINE(7)
#define OLED_LINE_8               LINE(8)
#define OLED_LINE_9               LINE(9)
#define OLED_LINE_10              LINE(10)
#define OLED_LINE_11              LINE(11)
#define OLED_LINE_12              LINE(12)
#define OLED_LINE_13              LINE(13)
#define OLED_LINE_14              LINE(14)
#define OLED_LINE_15              LINE(15)
#define OLED_LINE_16              LINE(16)
#define OLED_LINE_17              LINE(17)
#define OLED_LINE_18              LINE(18)
#define OLED_LINE_19              LINE(19)
#define OLED_LINE_20              LINE(20)
#define OLED_LINE_21              LINE(21)
#define OLED_LINE_22              LINE(22)
#define OLED_LINE_23              LINE(23)
#define OLED_LINE_24              LINE(24)
#define OLED_LINE_25              LINE(25)
#define OLED_LINE_26              LINE(26)
#define OLED_LINE_27              LINE(27)
#define OLED_LINE_28              LINE(28)
#define OLED_LINE_29              LINE(29)

#define Line0                    OLED_LINE_0
#define Line1                    OLED_LINE_1
#define Line2                    OLED_LINE_2
#define Line3                    OLED_LINE_3
#define Line4                    OLED_LINE_4
#define Line5                    OLED_LINE_5
#define Line6                    OLED_LINE_6
#define Line7                    OLED_LINE_7
#define Line8                    OLED_LINE_8
#define Line9                    OLED_LINE_9

/** 
  * @brief OLED default font 
  */ 
#define OLED_DEFAULT_FONT         Font16x24

/** 
  * @brief  OLED Direction  
  */ 
#define OLED_DIR_HORIZONTAL       0x0000
#define OLED_DIR_VERTICAL         0x0001

/** 
  * @brief  OLED Size (Width and Height)  
  */ 
#define OLED_PIXEL_WIDTH          320
#define OLED_PIXEL_HEIGHT         240

/**
  * @}
  */ 

/** @defgroup STM32F4_DISCOVERY_OLED_Exported_Macros
  * @{
  */
#define ASSEMBLE_RGB(R ,G, B)    ((((R)& 0xF8) << 8) | (((G) & 0xFC) << 3) | (((B) & 0xF8) >> 3)) 
/**
  * @}
  */ 

/** @defgroup STM32F4_DISCOVERY_OLED_Exported_Functions
  * @{
  */ 
/** @defgroup  
  * @{
  */
void OLED_DeInit(void);   
void STM32f4_Discovery_OLED_Init(void);
void OLED_RGB_Test(void);
void OLED_SetColors(__IO uint16_t _TextColor, __IO uint16_t _BackColor); 
void OLED_GetColors(__IO uint16_t *_TextColor, __IO uint16_t *_BackColor);
void OLED_SetTextColor(__IO uint16_t Color);
void OLED_SetBackColor(__IO uint16_t Color);
void OLED_ClearLine(uint16_t Line);
void OLED_Clear(uint16_t Color);
void OLED_SetCursor(uint16_t Xpos, uint16_t Ypos);
void OLED_DrawChar(uint16_t Xpos, uint16_t Ypos, const uint16_t *c);
void OLED_DisplayChar(uint16_t Line, uint16_t Column, uint8_t Ascii);
void OLED_SetFont(sFONT *fonts);
sFONT *OLED_GetFont(void);
void OLED_DisplayStringLine(uint16_t Line, uint8_t *ptr);
void OLED_SetDisplayWindow(uint16_t Xpos, uint16_t Ypos, uint16_t Height, uint16_t Width);
void OLED_WindowModeDisable(void);
void OLED_DrawLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length, uint8_t Direction);
void OLED_DrawRect(uint16_t Xpos, uint16_t Ypos, uint8_t Height, uint16_t Width);
void OLED_DrawCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius);
void OLED_DrawMonoPict(const uint32_t *Pict);
void OLED_WriteBMP(uint32_t BmpAddress);
void OLED_DrawUniLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
void OLED_DrawFullRect(uint16_t Xpos, uint16_t Ypos, uint16_t Width, uint16_t Height);
void OLED_DrawFullCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius);
void OLED_PolyLine(pPoint Points, uint16_t PointCount);
void OLED_PolyLineRelative(pPoint Points, uint16_t PointCount);
void OLED_ClosedPolyLine(pPoint Points, uint16_t PointCount);
void OLED_ClosedPolyLineRelative(pPoint Points, uint16_t PointCount);
void OLED_FillPolyLine(pPoint Points, uint16_t PointCount);
/**
  * @}
  */ 

/** @defgroup  
  * @{
  */ 
void OLED_WriteReg(uint8_t OLED_Reg, uint16_t OLED_RegValue);
uint16_t OLED_ReadReg(uint8_t OLED_Reg);
void OLED_WriteRAM_Prepare(void);
void OLED_WriteRAM(uint16_t RGB_Code);
uint16_t OLED_ReadRAM(void);
void OLED_PowerOn(void);
void OLED_DisplayOn(void);
void OLED_DisplayOff(void);
/**
  * @}
  */ 

/** @defgroup
  * @{
  */ 
void OLED_CtrlLinesConfig(void);
void OLED_FSMCConfig(void);
/**
  * @}
  */
/**
  * @}
  */    
#ifdef __cplusplus
}
#endif

#endif /* __STM32F4_DISCOVERY_OLED_H */
/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */ 

/*********** Portions COPYRIGHT 2012 Embest Tech. Co., Ltd.*****END OF FILE****/
