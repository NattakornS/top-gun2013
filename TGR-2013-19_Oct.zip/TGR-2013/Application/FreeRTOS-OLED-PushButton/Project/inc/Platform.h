/**
  ******************************************************************************
  * @file    Platform.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#include "stm32f4_discovery.h"
#include "stm32f4_discovery_lcd.h"
#include "stm32f4xx_gpio.h"

#define RS485_UART			USART3
#define RS485_UART_CLK			RCC_APB1Periph_USART3
#define RS485_UART_CLK_INIT		RCC_APB1PeriphClockCmd
#define RS485_IRQn			USART3_IRQn
#define RS485_IRQHandler		USART3_IRQHandler

#define RS485_TX_PIN                    GPIO_Pin_8                
#define RS485_TX_GPIO_PORT              GPIOD                       
#define RS485_TX_GPIO_CLK               RCC_AHB1Periph_GPIOD
#define RS485_TX_SOURCE                 GPIO_PinSource8
#define RS485_TX_AF                     GPIO_AF_USART3

#define RS485_RX_PIN                    GPIO_Pin_9                
#define RS485_RX_GPIO_PORT              GPIOD                    
#define RS485_RX_GPIO_CLK               RCC_AHB1Periph_GPIOD
#define RS485_RX_SOURCE                 GPIO_PinSource9
#define RS485_RX_AF                     GPIO_AF_USART3

#define RS485_DIR_PIN                   GPIO_Pin_8               
#define RS485_DIR_GPIO_PORT             GPIOA                    
#define RS485_DIR_GPIO_CLK              RCC_AHB1Periph_GPIOA


#define RS458_DIR_RX()	{ RS485_DIR_GPIO_PORT->BSRRH = RS485_DIR_PIN; }
#define RS458_DIR_TX()	{ RS485_DIR_GPIO_PORT->BSRRL = RS485_DIR_PIN; }

//-----------------------------------------------------------------------------

#define AirCon_UART		       	UART5
#define AirCon_UART_CLK		        RCC_APB1Periph_UART5
#define AirCon_UART_CLK_INIT		RCC_APB1PeriphClockCmd
#define AirCon_IRQn			UART5_IRQn
#define AirCon_IRQHandler	        UART5_IRQHandler

#define AirCon_TX_PIN                   GPIO_Pin_12
#define AirCon_TX_GPIO_PORT             GPIOC
#define AirCon_TX_GPIO_CLK              RCC_AHB1Periph_GPIOC
#define AirCon_TX_SOURCE                GPIO_PinSource12
#define AirCon_TX_AF                    GPIO_AF_UART5

#define AirCon_RX_PIN                   GPIO_Pin_2
#define AirCon_RX_GPIO_PORT             GPIOD               
#define AirCon_RX_GPIO_CLK              RCC_AHB1Periph_GPIOD
#define AirCon_RX_SOURCE                GPIO_PinSource2
#define AirCon_RX_AF                    GPIO_AF_UART5

//-----------------------------------------------------------------------------

#define Zigbee_UART			USART6
#define Zigbee_UART_CLK			RCC_APB2Periph_USART6
#define Zigbee_UART_CLK_INIT		RCC_APB2PeriphClockCmd
#define Zigbee_IRQn			USART6_IRQn
#define Zigbee_IRQHandler		USART6_IRQHandler


#define Zigbee_TX_PIN                       GPIO_Pin_6
#define Zigbee_TX_GPIO_PORT                 GPIOC
#define Zigbee_TX_GPIO_CLK                  RCC_AHB1Periph_GPIOC
#define Zigbee_TX_SOURCE                    GPIO_PinSource6
#define Zigbee_TX_AF                        GPIO_AF_USART6

#define Zigbee_RX_PIN                       GPIO_Pin_7                
#define Zigbee_RX_GPIO_PORT                 GPIOC                    
#define Zigbee_RX_GPIO_CLK                  RCC_AHB1Periph_GPIOC
#define Zigbee_RX_SOURCE                    GPIO_PinSource7
#define Zigbee_RX_AF                        GPIO_AF_USART6

//-----------------------------------------------------------------------------

#define NFC_UART		       	USART2
#define NFC_UART_CLK		        RCC_APB1Periph_USART2
#define NFC_UART_CLK_INIT		RCC_APB1PeriphClockCmd
#define NFC_IRQn			USART2_IRQn
#define NFC_IRQHandler	                USART2_IRQHandler

#define NFC_TX_PIN                      GPIO_Pin_2
#define NFC_TX_GPIO_PORT                GPIOA
#define NFC_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define NFC_TX_SOURCE                   GPIO_PinSource2
#define NFC_TX_AF                       GPIO_AF_USART2

#define NFC_RX_PIN                      GPIO_Pin_3
#define NFC_RX_GPIO_PORT                GPIOA               
#define NFC_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define NFC_RX_SOURCE                   GPIO_PinSource3
#define NFC_RX_AF                       GPIO_AF_USART2

//-----------------------------------------------------------------------------
#define PushButton_PIN                 GPIO_Pin_0 
#define PushButton_GPIO_PORT           GPIOA
#define PushButton_GPIO_CLK            RCC_AHB1Periph_GPIOA
#define PushButton_EXTI_LINE           EXTI_Line0
#define PushButton_IRQHandler          EXTI0_IRQHandler


#endif  // __PLATFORM_H__