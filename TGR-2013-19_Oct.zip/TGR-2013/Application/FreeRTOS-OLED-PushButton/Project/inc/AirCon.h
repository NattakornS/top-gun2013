/**
  ******************************************************************************
  * @file    AirCon.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#ifndef __AIRCON_H__
#define __AIRCON_H__

#include "Platform.h"
#include "FreeRTOS.h"
#define AIRCON_PACKET_SIZE      30

typedef struct {
  uint16_t State;
  uint16_t Size;
  uint8_t  Data[30];
}tAirCon_Buffer;


typedef struct
{
  uint16_t Source;
  uint16_t Type;
  uint16_t Timer;
  uint8_t *Data;
} tAirCon_Message;

typedef enum
{
  AIRCON_API_COMMAND    = 0x01,
  AIRCON_DRIVER_DATA    = 0x10,
  AIRCON_POWER_ON       = 0x11,
  AIRCON_POWER_OFF      = 0x12,
  AIRCON_TX_DATA        = 0x13,
  AIRCON_RX_DATA        = 0x14,
  AIRCON_GET_STATUS     = 0x15,
  AIRCON_FAN_LEVEL      = 0x20,
  AIRCON_FAN_AUTO       = 0x21,
  AIRCON_FAN_LOW        = 0x22,
  AIRCON_FAN_MEDIUM     = 0x23,
  AIRCON_FAN_HIGH       = 0x24,
  AIRCON_FAN_VERYHIGH   = 0x25,
  AIRCON_FAN_TURBO      = 0x26,
  AIRCON_FAN_MAX        = 0x27
} tAirCon_Command;

typedef enum
{
  POWER_OFF                  = 0x00,
  POWER_ON                   = 0x02,
  FAN_LEVEL                  = 0x03
} tAirCon_State;


void AirCon_Driver_Config(void);
void AirCon_Data_Process(uint8_t *ptrAPI);
void AirCon_API_Process(uint8_t *ptrAPI);
void AirCon_POWER_ON(portTickType xTicksToWait);
void AirCon_POWER_OFF(portTickType xTicksToWait);
void AirCon_FAN_LEVEL(portTickType xTicksToWait);
void AirCon_GET_STATUS(portTickType xTicksToWait);
void AirCon_Get_Data(uint16_t Size);


#endif // __AIRCON_H__