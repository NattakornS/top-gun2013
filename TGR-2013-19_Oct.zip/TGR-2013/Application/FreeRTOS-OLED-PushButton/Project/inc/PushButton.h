/**
  ******************************************************************************
  * @file    PushButton.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#ifndef __PUSHBUTTON_H__
#define __PUSHBUTTON_H__

#include "FreeRTOS.h"
#include "queue.h"
#include "FreeRTOS_Priority.h"
#include "Platform.h"
    
#define PUSHBUTTON_QUEUE_SIZE   10

void PushButton_Driver_Config(void);
void PushButton_Press(void);

#endif  //__PUSHBUTTON_H__