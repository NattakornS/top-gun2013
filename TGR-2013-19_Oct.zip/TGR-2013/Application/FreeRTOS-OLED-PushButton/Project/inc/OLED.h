/**
  ******************************************************************************
  * @file    OLED.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#ifndef __OLED_H__
#define __OLED_H__


void display_one_letter (unsigned char z, unsigned char column, unsigned char line);
void display_big (unsigned char z, unsigned char column, unsigned char line);
void lcd_Str(char colum, char line, char *s);
void lcd_Str_big(char colum, char line, char *s);
void display_valiable( unsigned int x_posi,unsigned int y_posi,long x, int radix, int col, int d, int dot);

void Start_OLED_Task(void);
void OLED_String(uint8_t Pos_X, uint8_t Pos_Y, char *ptrString);

#endif  //__OLED_H__