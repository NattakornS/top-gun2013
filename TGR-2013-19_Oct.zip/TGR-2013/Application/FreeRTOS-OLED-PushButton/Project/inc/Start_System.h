/**
  ******************************************************************************
  * @file    Start_System.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

/* Private functions ---------------------------------------------------------*/

extern void Start_LED_Task(void);