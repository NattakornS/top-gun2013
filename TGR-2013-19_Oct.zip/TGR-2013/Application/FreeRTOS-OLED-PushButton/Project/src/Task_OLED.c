/**
  ******************************************************************************
  * @file    OLED_Task.c
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the mafLCDin.c 
  *          file.  
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4_discovery.h"
#include "stm32f4_discovery_OLED.h"
#include "FreeRTOS.h"
#include "FreeRTOS_Priority.h"
#include "queue.h"
#include "OLED.h"

/* Global functions ---------------------------------------------------------*/


/* Private functions ---------------------------------------------------------*/
static void Setup_OLED(void);
static uint32_t Init_Task_OLED(void);
static void Task_OLED(void *);

/* External Reference functions ---------------------------------------------------------*/
//extern void STM32f4_Discovery_OLED_Init(void);
extern void Oled_SSD1305_Init(void);

//*****************************************************************************
//
// the data structure defines  for message OLED on OLED panel
//
//*****************************************************************************
typedef struct
{
    unsigned long Type;
    unsigned short X;
    unsigned short Y;
    char *Msg;
}
tOLED_Message;

//*****************************************************************************
//
// Defines to indicate the contents of the OLED message.
//
//*****************************************************************************
#define OLED_CHAR               1
#define OLED_STRING             2
#define OLED_CHAR_BIG           3
#define OLED_STRING_BIG         4


//*****************************************************************************
//
// The item size, queue size, and memory size for the OLED message queue.
//
//*****************************************************************************
#define OLED_ITEM_SIZE       sizeof(tOLEDMessage)
#define OLED_QUEUE_SIZE      10
#define OLED_MEM_SIZE        ((OLED_ITEM_SIZE * OLED_QUEUE_SIZE) +   \
                                 portQUEUE_OVERHEAD_BYTES)


//*****************************************************************************
//
// The queue for  sending messages to the OLED task.
//
//*****************************************************************************
static xQueueHandle tOLEDQueue;

/******************************************************************************/
/*                    OLED Task for STM32F407 Discovery                        */
/******************************************************************************/

void Start_OLED_Task(void)
{
  Setup_OLED();
  Init_Task_OLED();
}

// ----------------------------------------------------------------------------
//   * @brief -  Setup  Embest OLED Panel
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
void Setup_OLED(void)
{
  /* Initialize Embest's OLED  */
  Oled_SSD1305_Init();

}

// ----------------------------------------------------------------------------
//   * @brief -  Intialize OLED OLED Task 
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------

uint32_t Init_Task_OLED(void)
{

  // Create a queue capable of containing 10 unsigned long values.
  tOLEDQueue = xQueueCreate( 20, sizeof( tOLED_Message ) );
  if( tOLEDQueue == 0 ) {
    // Queue was not created and must not be used.
    return(1);
  }

  /* Start toogleLed4 task : Toggle LED4  every 250ms */
  if (xTaskCreate(Task_OLED, "OLED", configMINIMAL_STACK_SIZE, NULL, OLED_TASK_PRIORITY, NULL) != pdPASS) {
    return(1);
  }
  
  return(0);
}

// ----------------------------------------------------------------------------
//   * @brief -  This task for OLED OLED 
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------

void Task_OLED(void * pvParameters)
{

  tOLED_Message OLEDMsg;

  for(;;)
  {  
    xQueueReceive( tOLEDQueue, &OLEDMsg, ( portTickType )portMAX_DELAY);           
    switch(OLEDMsg.Type)
    {
      case OLED_CHAR: 
        {
          display_one_letter( *(OLEDMsg.Msg), OLEDMsg.X, OLEDMsg.Y); 
          break;
        }
      case OLED_STRING:       
        { 
          lcd_Str(OLEDMsg.X, OLEDMsg.Y, OLEDMsg.Msg);
          break;
        }      
      case OLED_CHAR_BIG:
        {
          lcd_Str_big( OLEDMsg.X, OLEDMsg.Y, OLEDMsg.Msg);
          break;
        }
      case OLED_STRING_BIG:
        {
          display_big(*(OLEDMsg.Msg),OLEDMsg.X,OLEDMsg.Y); 
          break;
        }
    }
    vTaskDelay(160);
  }
}


//*****************************************************************************
//
// Sends a request to the OLED task to draw a character on the OLED.
//
//*****************************************************************************
void OLED_Char(uint8_t Pos_X, uint8_t Pos_Y, char *ptrChar)
{
    tOLED_Message OLEDMessage;

    //
    // Construct the message to be sent.
    //
    OLEDMessage.Type = OLED_CHAR;
    OLEDMessage.X = Pos_X;
    OLEDMessage.Y = Pos_Y;
    OLEDMessage.Msg = ptrChar;

    //
    // Send the image draw request to the OLED task.
    //
    xQueueSend(tOLEDQueue, &OLEDMessage, portMAX_DELAY);
}

//*****************************************************************************
//
// Sends a request to the OLED task to draw a string on the OLED.
//
//*****************************************************************************
void OLED_String(uint8_t Pos_X, uint8_t Pos_Y, char *ptrString)
{
    tOLED_Message OLEDMessage;

    //
    // Construct the message to be sent.
    //
    OLEDMessage.Type = OLED_STRING;
    OLEDMessage.X = Pos_X;
    OLEDMessage.Y = Pos_Y;
    OLEDMessage.Msg = ptrString;

    //
    // Send the string draw request to the OLED task.
    //
    xQueueSend(tOLEDQueue, (void *) &OLEDMessage, portMAX_DELAY);
}

//*****************************************************************************
//
// // Sends a request to the OLED task to draw a character with big size on the OLED.
//
//*****************************************************************************
void OLED_Char_Big(uint8_t Pos_X, uint8_t Pos_Y,const uint8_t *ptrChar)
{
    tOLED_Message OLEDMessage;

    //
    // Construct the message to be sent.
    //
    OLEDMessage.Type = OLED_CHAR_BIG;
    OLEDMessage.X = Pos_X;
    OLEDMessage.Y = Pos_Y;

    //
    // Send the pen move request to the OLED task.
    //
    xQueueSend(tOLEDQueue, &OLEDMessage, portMAX_DELAY);
}

//*****************************************************************************
//
// Sends a request to the OLED task to draw a string with big character on the OLED.
//
//*****************************************************************************
void OLED_Draw(uint8_t Pos_X, uint8_t Pos_Y)
{
    tOLED_Message OLEDMessage;

    //
    // Construct the message to be sent.
    //
    OLEDMessage.Type = OLED_STRING_BIG;
    OLEDMessage.X = Pos_X;
    OLEDMessage.Y = Pos_Y;;

    //
    // Send the pen draw request to the OLED task.
    //
    xQueueSend(tOLEDQueue, &OLEDMessage, portMAX_DELAY);
}

