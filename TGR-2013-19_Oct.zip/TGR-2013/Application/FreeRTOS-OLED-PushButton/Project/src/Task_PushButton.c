/**
  ******************************************************************************
  * @file    PushButton.c
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */
  
#include "FreeRTOS.h"
#include "FreeRTOS_Priority.h"
#include "queue.h"
#include "Platform.h"
#include "PushButton.h"
#include "semphr.h"
#include "OLED.h"


#define TICKS_TO_WAIT	1
/* Global functions ---------------------------------------------------------*/

/* Private functions ---------------------------------------------------------*/
static void Setup_PushButton(void);
static uint32_t Init_Task_PushButton(void);
static void Task_PushButton(void *);


// ----- The queue for  sending messages to the LCD task.-----
xSemaphoreHandle PushButton_Semaphore = NULL;

/******************************************************************************/
/*                    Push Button Task for STM32F407 Discovery                        */
/******************************************************************************/

void Start_PushButton_Task(void)
{
  Setup_PushButton();
  Init_Task_PushButton();
}


// ----------------------------------------------------------------------------
//   * @brief -  Setup  PushButtonPushButton
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
void Setup_PushButton(void)
{
  PushButton_Driver_Config();  
}

// ----------------------------------------------------------------------------
//   * @brief -  Intialize PushButton Task 
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
uint32_t Init_Task_PushButton(void)
{
  
  // Create a queue capable of containing uint8_t values.
//  PushButtonQueue = xQueueCreate(PUSHBUTTON_QUEUE_SIZE, sizeof(uint8_t *) );
  
//  if( PushButtonQueue == 0 ) {return(1);} // Queue was not created and must not be used.
 
  vSemaphoreCreateBinary( PushButton_Semaphore );
  xSemaphoreTake(PushButton_Semaphore, portMAX_DELAY );

  if( PushButton_Semaphore == NULL ) return (1); 
  
  if (xTaskCreate(Task_PushButton, "PushButton", configMINIMAL_STACK_SIZE, NULL, PUSHBUTTON_TASK_PRIORITY, NULL)!=pdPASS){
    return (1);
  }  
 
  return (0);
}

// ----------------------------------------------------------------------------
//   * @brief -  This task for toggle 
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
void Task_PushButton(void * pvParameters)
{
  static uint8_t position = 0;     
    
  OLED_String((position%16),(position/16),"x");
  position++;
  
  for(;;) {
    xSemaphoreTake(PushButton_Semaphore, portMAX_DELAY );
    OLED_String((position%16),position/16,"0");
    position++;
  }
}


void PushButton_Press(void)
{
  static uint8_t ucLocalTickCount = 0;
 // static signed portBASE_TYPE xHigherPriorityTaskWoken=0;  
 
//  xHigherPriorityTaskWoken = pdFALSE; 
  ucLocalTickCount++;
      
  if( ucLocalTickCount >= TICKS_TO_WAIT )
  {
    xSemaphoreGive( PushButton_Semaphore);
    ucLocalTickCount = 0;
  }
//  if( xHigherPriorityTaskWoken != pdFALSE )
  {
  }
}