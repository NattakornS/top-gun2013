/**
  ******************************************************************************
  * @file    AirConxx.c
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "semphr.h"
#include "FreeRTOS_Priority.h"
#include "queue.h"
#include "Platform.h"
#include "AirCon.h"
#include "OLED.h"

/* Global functions ---------------------------------------------------------*/
void Start_AirCon_Task(void);

/* Private functions ---------------------------------------------------------*/
static void Setup_AirCon(void);
static uint32_t Init_Task_AirCon(void);
static void Task_AirCon(void *);

uint8_t AirConR_RX_Buffer[AIRCON_PACKET_SIZE];


/* External Reference functions ---------------------------------------------------------*/

//*****************************************************************************
//
// The queue for  sending messages to the LCD task.
//
//*****************************************************************************
static xQueueHandle AirConQueue;

xSemaphoreHandle AirConSemaphore = NULL;

/******************************************************************************/
/*                    AirCon Task for STM32F407 Discovery                        */
/******************************************************************************/

void Start_AirCon_Task(void)
{
  Setup_AirCon();
  Init_Task_AirCon();
}

// ----------------------------------------------------------------------------
//   * @brief -  Setup  AirConAirCon
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
void Setup_AirCon(void)
{
    AirCon_Driver_Config();
}

// ----------------------------------------------------------------------------
//   * @brief -  Intialize AirCon Task 
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------
uint32_t Init_Task_AirCon(void)
{
  
  AirConQueue = xQueueCreate( 20, sizeof( tAirCon_Message ) );
  if( AirConQueue == 0 ) { return(1); }// Queue was not created and must not be used.
      
//  vSemaphoreCreateBinary( AirConSemaphore );
//  if( AirConSemaphore == NULL ) return (1);
  
  /* Create AirCon Task */
  if (xTaskCreate(Task_AirCon, "AirCon", configMINIMAL_STACK_SIZE, NULL, AIRCON_TASK_PRIORITY, NULL)!= pdPASS) {
    return(1); }
  
  return (0);
}

// ----------------------------------------------------------------------------
//   * @brief -  This task for AirCon
//   * @param  pvParameters not used
// ----------------------------------------------------------------------------

void Task_AirCon(void * pvParameters)
{

  for(;;)
  {  
    vTaskDelay(0xff);
  }
}

//-----------------------------------------------------------------------------

void AirCon_Get_Data(uint16_t Size)
{
  static uint8_t position=64; // line 4    
    
  OLED_String((position%16),(position/16),"+");
  position++;
}


