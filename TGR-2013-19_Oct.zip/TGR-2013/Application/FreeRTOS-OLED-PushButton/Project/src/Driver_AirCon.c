/**
  ******************************************************************************
  * @file    Driver_AirCon.c
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */
#include "FreeRTOS.h"
#include "task.h"
#include "Platform.h"
#include "AirCon.h"
#include <stdio.h>
#include <string.h>

extern uint8_t AirConR_Rx_Buffer[];

//uint8_t AirCon_SYNC_Buffer[30];
//uint8_t AirCon_RESP_Buffer[8];
//uint8_t AirCon_CMD_Buffer[8];


tAirCon_Buffer AirCon_Rx_Buffer;
tAirCon_Buffer AirCon_Tx_Buffer;
tAirCon_State AirCon_State = POWER_OFF;

void AirCon_Driver_Config(void)
{
  USART_InitTypeDef USART_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  
  /* Enable GPIO clock */
  RCC_AHB1PeriphClockCmd(AirCon_TX_GPIO_CLK | AirCon_RX_GPIO_CLK, ENABLE);
  
  /* Enable USART clock */
  AirCon_UART_CLK_INIT(AirCon_UART_CLK	, ENABLE);
  
  /* Connect USART pins to AF7 */
  GPIO_PinAFConfig(AirCon_TX_GPIO_PORT, AirCon_TX_SOURCE, AirCon_TX_AF);
  GPIO_PinAFConfig(AirCon_RX_GPIO_PORT, AirCon_RX_SOURCE, AirCon_RX_AF);
  
  /* Configure USART Tx and Rx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Pin = AirCon_TX_PIN;
  GPIO_Init(AirCon_TX_GPIO_PORT, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = AirCon_RX_PIN;
  GPIO_Init(AirCon_RX_GPIO_PORT, &GPIO_InitStructure);
  
  /* Enable the USART OverSampling by 8 */
  USART_OverSampling8Cmd(AirCon_UART, ENABLE);  
  
  /* USARTx configuration ----------------------------------------------------*/
  /* USARTx configured as follow:
  - BaudRate = 5250000 baud
  - Maximum BaudRate that can be achieved when using the Oversampling by 8
  is: (USART APB Clock / 8) 
  Example: 
  - (USART3 APB1 Clock / 8) = (42 MHz / 8) = 5250000 baud
  - (USART1 APB2 Clock / 8) = (84 MHz / 8) = 10500000 baud
  - Maximum BaudRate that can be achieved when using the Oversampling by 16
  is: (USART APB Clock / 16) 
  Example: (USART3 APB1 Clock / 16) = (42 MHz / 16) = 2625000 baud
  Example: (USART1 APB2 Clock / 16) = (84 MHz / 16) = 5250000 baud
  - Word Length = 8 Bits
  - one Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  */ 
  USART_InitStructure.USART_BaudRate = 600;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(AirCon_UART, &USART_InitStructure);
  
  /* NVIC configuration */
  /* Configure the Priority Group to 2 bits */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);
  
  /* Enable the USARTx Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = AirCon_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  /* Enable USART */
  USART_Cmd(AirCon_UART, ENABLE);
  
//	/* Enabled USART Rx data from zigbee*/
  USART_ITConfig(AirCon_UART, USART_IT_RXNE, ENABLE);
 // dgAirCon_Power_Off();

}

void AirCon_Power_On(void)
{
}

void AirCon_Power_Off(void)
{
}

void AirCon_Fan_Level(void)
{
}

uint32_t AirCon_Status(void)
{
  return AirCon_State;
}

void AirCon_IRQHandler(void)
{          
  static uint16_t Rx_Index = 0;
  uint8_t Rx_Data;
  
  if (USART_GetITStatus(AirCon_UART, USART_IT_RXNE) == SET) {
    Rx_Data= USART_ReceiveData(AirCon_UART);
    if (++Rx_Index == 30) {
      Rx_Index=0;
      AirCon_Get_Data(Rx_Data);
    } 
  }
 
  /* USART in Tramitter mode */
  if (USART_GetITStatus(AirCon_UART, USART_IT_TXE) == SET) {
  }
}


void xAirCon_IRQHandler(void)
{          
  static uint16_t Tx_Index = 0;
  static uint16_t Rx_Index = 0;
  
  if (USART_GetITStatus(AirCon_UART, USART_IT_RXNE) == SET) {
    AirCon_Rx_Buffer.Data[Rx_Index++] = USART_ReceiveData(AirCon_UART);
    if (Rx_Index == AirCon_Rx_Buffer.Size) {
      Rx_Index=0;
      AirCon_Get_Data(AirCon_Rx_Buffer.Size);
    } 
  }
 
  /* USART in Tramitter mode */
  if (USART_GetITStatus(AirCon_UART, USART_IT_TXE) == SET) {
    if (Tx_Index < AirCon_Tx_Buffer.Size) { /* Send Transaction data */
      USART_SendData(AirCon_UART,AirCon_Tx_Buffer.Data[Tx_Index++]); }
    else {
      /* Disable the Tx buffer empty interrupt */
      USART_ITConfig(AirCon_UART, USART_IT_TXE, DISABLE); }
  }
}
