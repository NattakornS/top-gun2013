/**
  ******************************************************************************
  * @file    Driver_PushButton.c
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#include "Platform.h"
#include "PushButton.h"

void PushButton_Driver_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  EXTI_InitTypeDef  EXTI_InitStructure;
  NVIC_InitTypeDef  NVIC_InitStructure;

  RCC_AHB1PeriphClockCmd(PushButton_GPIO_CLK, ENABLE);

  GPIO_InitStructure.GPIO_Pin = PushButton_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(PushButton_GPIO_PORT, &GPIO_InitStructure); 

  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);

  EXTI_InitStructure.EXTI_Line = PushButton_EXTI_LINE;               
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;                                  
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE; 
  EXTI_Init(&EXTI_InitStructure);  
}

void PushButton_IRQHandler(void)
{

  if ((EXTI_GetITStatus(PushButton_EXTI_LINE) == SET))
  {
    PushButton_Press();
    EXTI_ClearITPendingBit(PushButton_EXTI_LINE);
  }
}

