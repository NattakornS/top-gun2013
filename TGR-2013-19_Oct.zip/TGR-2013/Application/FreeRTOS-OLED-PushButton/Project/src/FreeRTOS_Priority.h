/**
  ******************************************************************************
  * @file    FreeRTOSPriority.h
  * @author  Pirun Naka Team : Natavut Kwankeo
  * @version V1.0.0
  * @date    October-2013
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.  
  ******************************************************************************
  */

#ifndef __FREERTOS_PRIORITY_H
#define __FREERTOS_PRIORITY_H

#include "task.h"       // define tskIDLE_PRIORITY = (unsigned portBASE_TYPE )0)

#define AIRCON_TASK_PRIORITY            (tskIDLE_PRIORITY + 1 )
#define PUSHBUTTON_TASK_PRIORITY        (tskIDLE_PRIORITY + 2 )
#define OLED_TASK_PRIORITY              (tskIDLE_PRIORITY + 3 )


#endif // __FREERTOS_PRIORITY_H